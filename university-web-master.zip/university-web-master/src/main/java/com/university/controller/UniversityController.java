package com.university.controller;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.university.entity.UniversityDetailsDTO;
import com.university.service.UniversityService;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.net.URISyntaxException;

@Controller
public class UniversityController {

    @Autowired
    UniversityService universityService;


    @RequestMapping("/")
    public String home() {
        return "home";
    }

    @RequestMapping(value = "/universityDetails", produces = MediaType.APPLICATION_JSON_VALUE)
    public String getUniversityDetails(Model model) throws IOException, URISyntaxException {

        String details = universityService.getUniversitydetails();



        return "univDetails";
    }
}

