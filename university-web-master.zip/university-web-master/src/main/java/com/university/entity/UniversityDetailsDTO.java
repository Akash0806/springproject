package com.university.entity;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UniversityDetailsDTO implements Serializable{

    private String alpha_two_code;
    private String name;
    private String country;
    private String web_page;
    private String domain;

    private static final long serialVersionUID = 1L;

    public UniversityDetailsDTO() {
    }

    public UniversityDetailsDTO(String alpha_two_code, String name, String country, String web_page, String domain) {
        this.alpha_two_code = alpha_two_code;
        this.name = name;
        this.country = country;
        this.web_page = web_page;
        this.domain = domain;
    }

    public String getAlpha_two_code() {
        return alpha_two_code;
    }

    public void setAlpha_two_code(String alpha_two_code) {
        this.alpha_two_code = alpha_two_code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getWeb_page() {
        return web_page;
    }

    public void setWeb_page(String web_page) {
        this.web_page = web_page;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UniversityDetailsDTO that = (UniversityDetailsDTO) o;

        if (alpha_two_code != null ? !alpha_two_code.equals(that.alpha_two_code) : that.alpha_two_code != null)
            return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (country != null ? !country.equals(that.country) : that.country != null) return false;
        if (web_page != null ? !web_page.equals(that.web_page) : that.web_page != null) return false;
        return domain != null ? domain.equals(that.domain) : that.domain == null;
    }

    @Override
    public int hashCode() {
        int result = alpha_two_code != null ? alpha_two_code.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (country != null ? country.hashCode() : 0);
        result = 31 * result + (web_page != null ? web_page.hashCode() : 0);
        result = 31 * result + (domain != null ? domain.hashCode() : 0);
        return result;
    }
}
