package com.university.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.List;

/**
 * Created by dsm2061 on 7/1/17.
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class UniversityDetails implements Serializable{
    List<UniversityDetailsDTO> universityDetailsDTO;

    public UniversityDetails() {
    }

    public UniversityDetails(List<UniversityDetailsDTO> universityDetailsDTO) {
        this.universityDetailsDTO = universityDetailsDTO;
    }

    public List<UniversityDetailsDTO> getUniversityDetailsDTO() {
        return universityDetailsDTO;
    }

    public void setUniversityDetailsDTO(List<UniversityDetailsDTO> universityDetailsDTO) {
        this.universityDetailsDTO = universityDetailsDTO;
    }
}
