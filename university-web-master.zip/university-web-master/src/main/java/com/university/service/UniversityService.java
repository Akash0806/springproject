package com.university.service;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.university.entity.UniversityDetails;
import com.university.entity.UniversityDetailsDTO;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.List;

@Service
public class UniversityService {

    final String api_url = "http://localhost:8090/details";

    public String getUniversitydetails() throws URISyntaxException, IOException {

        RestTemplate restTemplate = new RestTemplate();

        ObjectMapper mapper = new ObjectMapper();
        String universityDetailsDTO =  restTemplate.getForObject(api_url, String.class);

        ObjectMapper objectMapper;
        objectMapper = new ObjectMapper().configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);


        Collection<Object> readValues = new ObjectMapper().readValue(universityDetailsDTO, new TypeReference<Collection<Object>>() { });

        System.out.println(universityDetailsDTO);


        return universityDetailsDTO;
    }
}




//        ResponseEntity<Object[]> responseEntity = restTemplate.getForEntity(api_url, Object[].class);
//        Object[] objects = responseEntity.getBody();
//        MediaType contentType = responseEntity.getHeaders().getContentType();
//        HttpStatus statusCode = responseEntity.getStatusCode();
//UniversityDetails response  = restTemplate.getForObject(api_url, UniversityDetails.class);

//List<UniversityDetailsDTO> myObjects = mapper.readValue(universityDetailsDTO, mapper.getTypeFactory().constructCollectionType(List.class, UniversityDetailsDTO.class));
//UniversityDetailsDTO[] myObjects = mapper.readValue(universityDetailsDTO, UniversityDetailsDTO[].class);
