package com.univ.service;


import com.google.gson.Gson;
import com.univ.entity.UniversityDetailsDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service("unisersityDetailsService")
public class UnisersityDetailsService {

    final String API_URL = "http://universities.hipolabs.com/search?name=technical&country=turkey";
    RestTemplate restTemplate = new RestTemplate();

    public String getUniversityDetails() {

        String universityDetailsDTO =  restTemplate.getForObject(API_URL, String.class);
        Gson gson = new Gson();
        String universityDetails = gson.toJson(universityDetailsDTO);
        return universityDetails;

    }

}

