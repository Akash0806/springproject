package com.univ.controller;


import com.univ.service.UnisersityDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UniversityDetailsController{

    @Autowired
    UnisersityDetailsService unisersityDetailsService;


    @RequestMapping(value = "/details" , produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    public @ResponseBody String getUniversityDetails(){
        String universityDetails= unisersityDetailsService.getUniversityDetails();
        return universityDetails;
    }

}
